import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { employeesTable } from "./employees";
import { leadsTable } from "./leads";

export const followUpsTable = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  bde_id: integer("bde_id")
    .notNull()
    .references(() => employeesTable.id),
  lead_id: integer("lead_id").references(() => leadsTable.id),
  client_name: text("client_name").notNull(),
  follow_up_date: text("follow_up_date").notNull(),
  notes: text("notes"),
  done: boolean("done").notNull().default(false),
  created_at: timestamp("created_at", { mode: "string" }).defaultNow().notNull(),
});

export const insertFollowUpSchema = createInsertSchema(followUpsTable).omit({
  id: true,
  created_at: true,
  done: true,
});

export type InsertFollowUp = z.infer<typeof insertFollowUpSchema>;
export type FollowUp = typeof followUpsTable.$inferSelect;
