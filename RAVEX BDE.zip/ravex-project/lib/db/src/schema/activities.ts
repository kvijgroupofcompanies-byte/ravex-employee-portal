import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { employeesTable } from "./employees";

export const activitiesTable = pgTable("activities", {
  id: serial("id").primaryKey(),
  bde_id: integer("bde_id")
    .notNull()
    .references(() => employeesTable.id),
  action: text("action").notNull(),
  description: text("description"),
  created_at: timestamp("created_at", { mode: "string" }).defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activitiesTable).omit({
  id: true,
  created_at: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activitiesTable.$inferSelect;
