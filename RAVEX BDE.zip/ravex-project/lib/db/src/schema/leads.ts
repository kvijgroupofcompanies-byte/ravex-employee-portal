import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { employeesTable } from "./employees";

export const leadsTable = pgTable("leads", {
  id: serial("id").primaryKey(),
  bde_id: integer("bde_id")
    .notNull()
    .references(() => employeesTable.id),
  client_name: text("client_name").notNull(),
  business_name: text("business_name"),
  phone: text("phone"),
  requirement: text("requirement"),
  budget: text("budget"),
  notes: text("notes"),
  status: text("status").notNull().default("new"),
  created_at: timestamp("created_at", { mode: "string" }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { mode: "string" }).defaultNow().notNull(),
});

export const insertLeadSchema = createInsertSchema(leadsTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leadsTable.$inferSelect;
