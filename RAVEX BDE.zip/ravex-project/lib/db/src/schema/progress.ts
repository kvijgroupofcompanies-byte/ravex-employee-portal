import { pgTable, serial, integer, text } from "drizzle-orm/pg-core";
import { timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { employeesTable } from "./employees";

export const dailyProgressTable = pgTable("daily_progress", {
  id: serial("id").primaryKey(),
  bde_id: integer("bde_id")
    .notNull()
    .references(() => employeesTable.id),
  date: text("date").notNull(),
  messages_sent: integer("messages_sent").notNull().default(0),
  leads_added: integer("leads_added").notNull().default(0),
  interested_leads: integer("interested_leads").notNull().default(0),
  follow_ups_done: integer("follow_ups_done").notNull().default(0),
  sales_closed: integer("sales_closed").notNull().default(0),
  created_at: timestamp("created_at", { mode: "string" }).defaultNow().notNull(),
});

export const insertDailyProgressSchema = createInsertSchema(dailyProgressTable).omit({
  id: true,
  created_at: true,
});

export type InsertDailyProgress = z.infer<typeof insertDailyProgressSchema>;
export type DailyProgress = typeof dailyProgressTable.$inferSelect;
