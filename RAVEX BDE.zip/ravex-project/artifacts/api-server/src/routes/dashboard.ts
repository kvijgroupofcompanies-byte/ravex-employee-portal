import { Router, type IRouter } from "express";
import { db, leadsTable, followUpsTable, dailyProgressTable, employeesTable } from "@workspace/db";
import { eq, count, sum } from "drizzle-orm";
import {
  GetAdminDashboardResponse,
  GetPerformanceResponse,
} from "@workspace/api-zod";
import { requireAdmin, requireAuth, getSessionEmployee } from "../middlewares/auth";

const router: IRouter = Router();

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

router.get("/dashboard/admin", requireAdmin, async (_req, res): Promise<void> => {
  const [totalLeads] = await db.select({ count: count() }).from(leadsTable);
  const [totalFollowups] = await db.select({ count: count() }).from(followUpsTable);
  const [totalInterested] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.status, "interested"));
  const [totalSales] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.status, "closed"));
  const [totalEmployees] = await db.select({ count: count() }).from(employeesTable).where(eq(employeesTable.role, "bde"));
  const [pendingFollowups] = await db.select({ count: count() }).from(followUpsTable).where(eq(followUpsTable.done, false));

  const todayProgress = await db
    .select({ messages: sum(dailyProgressTable.messages_sent) })
    .from(dailyProgressTable)
    .where(eq(dailyProgressTable.date, todayStr()));

  const dashboard = {
    total_leads: totalLeads.count,
    total_followups: totalFollowups.count,
    total_interested: totalInterested.count,
    total_sales: totalSales.count,
    total_employees: totalEmployees.count,
    messages_today: Number(todayProgress[0]?.messages ?? 0),
    pending_followups: pendingFollowups.count,
  };

  res.json(GetAdminDashboardResponse.parse(dashboard));
});

router.get("/dashboard/performance", requireAdmin, async (_req, res): Promise<void> => {
  const employees = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.role, "bde"));

  const performance = await Promise.all(
    employees.map(async (emp) => {
      const [totalLeads] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.bde_id, emp.id));
      const [interested] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.bde_id, emp.id));
      const [closed] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.status, "closed"));
      const [followUps] = await db.select({ count: count() }).from(followUpsTable).where(eq(followUpsTable.bde_id, emp.id));

      const progressRows = await db
        .select({ messages: sum(dailyProgressTable.messages_sent) })
        .from(dailyProgressTable)
        .where(eq(dailyProgressTable.bde_id, emp.id));

      return {
        bde_id: emp.id,
        bde_name: emp.name,
        total_leads: totalLeads.count,
        interested_leads: interested.count,
        closed_sales: closed.count,
        messages_sent: Number(progressRows[0]?.messages ?? 0),
        follow_ups: followUps.count,
      };
    })
  );

  res.json(GetPerformanceResponse.parse(performance));
});

export default router;
