import { Router, type IRouter } from "express";
import { db, activitiesTable, employeesTable } from "@workspace/db";
import { eq, and, SQL, desc } from "drizzle-orm";
import {
  ListActivitiesQueryParams,
  ListActivitiesResponse,
} from "@workspace/api-zod";
import { requireAuth, getSessionEmployee } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/activities", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const query = ListActivitiesQueryParams.safeParse(req.query);
  const conditions: SQL[] = [];

  if (emp.role !== "admin") {
    conditions.push(eq(activitiesTable.bde_id, emp.id));
  } else if (query.success && query.data.bde_id) {
    conditions.push(eq(activitiesTable.bde_id, query.data.bde_id));
  }

  const limit = (query.success && query.data.limit) ? query.data.limit : 100;

  const rows = await db
    .select({
      id: activitiesTable.id,
      bde_id: activitiesTable.bde_id,
      bde_name: employeesTable.name,
      action: activitiesTable.action,
      description: activitiesTable.description,
      created_at: activitiesTable.created_at,
    })
    .from(activitiesTable)
    .leftJoin(employeesTable, eq(activitiesTable.bde_id, employeesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(activitiesTable.created_at))
    .limit(limit);

  res.json(ListActivitiesResponse.parse(rows));
});

export default router;
