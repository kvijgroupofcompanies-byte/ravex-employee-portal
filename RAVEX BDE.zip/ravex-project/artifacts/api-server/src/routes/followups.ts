import { Router, type IRouter } from "express";
import { db, followUpsTable, employeesTable, activitiesTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import {
  ListFollowUpsQueryParams,
  CreateFollowUpBody,
  UpdateFollowUpParams,
  UpdateFollowUpBody,
  DeleteFollowUpParams,
  ListFollowUpsResponse,
  UpdateFollowUpResponse,
} from "@workspace/api-zod";
import { requireAuth, getSessionEmployee } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/followups", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const query = ListFollowUpsQueryParams.safeParse(req.query);
  const conditions: SQL[] = [];

  if (emp.role !== "admin") {
    conditions.push(eq(followUpsTable.bde_id, emp.id));
  } else if (query.success && query.data.bde_id) {
    conditions.push(eq(followUpsTable.bde_id, query.data.bde_id));
  }

  if (query.success && query.data.pending) {
    conditions.push(eq(followUpsTable.done, false));
  }

  const rows = await db
    .select({
      id: followUpsTable.id,
      bde_id: followUpsTable.bde_id,
      bde_name: employeesTable.name,
      lead_id: followUpsTable.lead_id,
      client_name: followUpsTable.client_name,
      follow_up_date: followUpsTable.follow_up_date,
      notes: followUpsTable.notes,
      done: followUpsTable.done,
      created_at: followUpsTable.created_at,
    })
    .from(followUpsTable)
    .leftJoin(employeesTable, eq(followUpsTable.bde_id, employeesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(followUpsTable.follow_up_date);

  res.json(ListFollowUpsResponse.parse(rows));
});

router.post("/followups", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const parsed = CreateFollowUpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [followUp] = await db
    .insert(followUpsTable)
    .values({ ...parsed.data, bde_id: emp.id })
    .returning();

  await db.insert(activitiesTable).values({
    bde_id: emp.id,
    action: "Follow-Up Created",
    description: `Follow-up created for: ${followUp.client_name} on ${followUp.follow_up_date}`,
  });

  const [row] = await db
    .select({
      id: followUpsTable.id,
      bde_id: followUpsTable.bde_id,
      bde_name: employeesTable.name,
      lead_id: followUpsTable.lead_id,
      client_name: followUpsTable.client_name,
      follow_up_date: followUpsTable.follow_up_date,
      notes: followUpsTable.notes,
      done: followUpsTable.done,
      created_at: followUpsTable.created_at,
    })
    .from(followUpsTable)
    .leftJoin(employeesTable, eq(followUpsTable.bde_id, employeesTable.id))
    .where(eq(followUpsTable.id, followUp.id));

  res.status(201).json(row);
});

router.patch("/followups/:id", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = UpdateFollowUpParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = UpdateFollowUpBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [updated] = await db
    .update(followUpsTable)
    .set(parsed.data)
    .where(eq(followUpsTable.id, params.data.id))
    .returning();

  if (!updated) { res.status(404).json({ error: "Follow-up not found" }); return; }

  if (parsed.data.done) {
    await db.insert(activitiesTable).values({
      bde_id: emp.id,
      action: "Follow-Up Done",
      description: `Follow-up completed for: ${updated.client_name}`,
    });
  }

  const [row] = await db
    .select({
      id: followUpsTable.id,
      bde_id: followUpsTable.bde_id,
      bde_name: employeesTable.name,
      lead_id: followUpsTable.lead_id,
      client_name: followUpsTable.client_name,
      follow_up_date: followUpsTable.follow_up_date,
      notes: followUpsTable.notes,
      done: followUpsTable.done,
      created_at: followUpsTable.created_at,
    })
    .from(followUpsTable)
    .leftJoin(employeesTable, eq(followUpsTable.bde_id, employeesTable.id))
    .where(eq(followUpsTable.id, params.data.id));

  res.json(UpdateFollowUpResponse.parse(row));
});

router.delete("/followups/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteFollowUpParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  await db.delete(followUpsTable).where(eq(followUpsTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
