import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import employeesRouter from "./employees";
import leadsRouter from "./leads";
import followupsRouter from "./followups";
import progressRouter from "./progress";
import activitiesRouter from "./activities";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(employeesRouter);
router.use(leadsRouter);
router.use(followupsRouter);
router.use(progressRouter);
router.use(activitiesRouter);
router.use(dashboardRouter);

export default router;
