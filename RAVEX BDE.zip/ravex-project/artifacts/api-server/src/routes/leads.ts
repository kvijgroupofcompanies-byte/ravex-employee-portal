import { Router, type IRouter } from "express";
import { db, leadsTable, employeesTable, activitiesTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import {
  ListLeadsQueryParams,
  CreateLeadBody,
  GetLeadParams,
  UpdateLeadParams,
  UpdateLeadBody,
  DeleteLeadParams,
  ListLeadsResponse,
  GetLeadResponse,
  UpdateLeadResponse,
} from "@workspace/api-zod";
import { requireAuth, getSessionEmployee } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/leads", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const query = ListLeadsQueryParams.safeParse(req.query);

  const conditions: SQL[] = [];
  if (emp.role !== "admin") {
    conditions.push(eq(leadsTable.bde_id, emp.id));
  } else if (query.success && query.data.bde_id) {
    conditions.push(eq(leadsTable.bde_id, query.data.bde_id));
  }
  if (query.success && query.data.status) {
    conditions.push(eq(leadsTable.status, query.data.status));
  }

  const rows = await db
    .select({
      id: leadsTable.id,
      bde_id: leadsTable.bde_id,
      bde_name: employeesTable.name,
      client_name: leadsTable.client_name,
      business_name: leadsTable.business_name,
      phone: leadsTable.phone,
      requirement: leadsTable.requirement,
      budget: leadsTable.budget,
      notes: leadsTable.notes,
      status: leadsTable.status,
      created_at: leadsTable.created_at,
      updated_at: leadsTable.updated_at,
    })
    .from(leadsTable)
    .leftJoin(employeesTable, eq(leadsTable.bde_id, employeesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(leadsTable.created_at);

  res.json(ListLeadsResponse.parse(rows));
});

router.post("/leads", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const parsed = CreateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [lead] = await db
    .insert(leadsTable)
    .values({ ...parsed.data, bde_id: emp.id })
    .returning();

  await db.insert(activitiesTable).values({
    bde_id: emp.id,
    action: "Lead Added",
    description: `Lead added: ${lead.client_name}`,
  });

  const [row] = await db
    .select({
      id: leadsTable.id,
      bde_id: leadsTable.bde_id,
      bde_name: employeesTable.name,
      client_name: leadsTable.client_name,
      business_name: leadsTable.business_name,
      phone: leadsTable.phone,
      requirement: leadsTable.requirement,
      budget: leadsTable.budget,
      notes: leadsTable.notes,
      status: leadsTable.status,
      created_at: leadsTable.created_at,
      updated_at: leadsTable.updated_at,
    })
    .from(leadsTable)
    .leftJoin(employeesTable, eq(leadsTable.bde_id, employeesTable.id))
    .where(eq(leadsTable.id, lead.id));

  res.status(201).json(GetLeadResponse.parse(row));
});

router.get("/leads/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetLeadParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [row] = await db
    .select({
      id: leadsTable.id,
      bde_id: leadsTable.bde_id,
      bde_name: employeesTable.name,
      client_name: leadsTable.client_name,
      business_name: leadsTable.business_name,
      phone: leadsTable.phone,
      requirement: leadsTable.requirement,
      budget: leadsTable.budget,
      notes: leadsTable.notes,
      status: leadsTable.status,
      created_at: leadsTable.created_at,
      updated_at: leadsTable.updated_at,
    })
    .from(leadsTable)
    .leftJoin(employeesTable, eq(leadsTable.bde_id, employeesTable.id))
    .where(eq(leadsTable.id, params.data.id));

  if (!row) { res.status(404).json({ error: "Lead not found" }); return; }
  res.json(GetLeadResponse.parse(row));
});

router.patch("/leads/:id", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = UpdateLeadParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = UpdateLeadBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [updated] = await db
    .update(leadsTable)
    .set({ ...parsed.data, updated_at: new Date() })
    .where(eq(leadsTable.id, params.data.id))
    .returning();

  if (!updated) { res.status(404).json({ error: "Lead not found" }); return; }

  if (parsed.data.status === "interested") {
    await db.insert(activitiesTable).values({
      bde_id: emp.id,
      action: "Lead Marked Interested",
      description: `Lead marked interested: ${updated.client_name}`,
    });
  } else if (parsed.data.status === "closed") {
    await db.insert(activitiesTable).values({
      bde_id: emp.id,
      action: "Sale Closed",
      description: `Sale closed: ${updated.client_name}`,
    });
  } else if (parsed.data.status) {
    await db.insert(activitiesTable).values({
      bde_id: emp.id,
      action: "Lead Updated",
      description: `Lead status updated to ${parsed.data.status}: ${updated.client_name}`,
    });
  }

  const [row] = await db
    .select({
      id: leadsTable.id,
      bde_id: leadsTable.bde_id,
      bde_name: employeesTable.name,
      client_name: leadsTable.client_name,
      business_name: leadsTable.business_name,
      phone: leadsTable.phone,
      requirement: leadsTable.requirement,
      budget: leadsTable.budget,
      notes: leadsTable.notes,
      status: leadsTable.status,
      created_at: leadsTable.created_at,
      updated_at: leadsTable.updated_at,
    })
    .from(leadsTable)
    .leftJoin(employeesTable, eq(leadsTable.bde_id, employeesTable.id))
    .where(eq(leadsTable.id, params.data.id));

  res.json(UpdateLeadResponse.parse(row));
});

router.delete("/leads/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteLeadParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  await db.delete(leadsTable).where(eq(leadsTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
