import { Router, type IRouter } from "express";
import { db, dailyProgressTable, activitiesTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import {
  ListProgressQueryParams,
  UpdateTodayProgressBody,
  ListProgressResponse,
  GetTodayProgressResponse,
  UpdateTodayProgressResponse,
} from "@workspace/api-zod";
import { requireAuth, getSessionEmployee } from "../middlewares/auth";

const router: IRouter = Router();

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

router.get("/progress", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const query = ListProgressQueryParams.safeParse(req.query);
  const conditions: SQL[] = [];

  if (emp.role !== "admin") {
    conditions.push(eq(dailyProgressTable.bde_id, emp.id));
  } else if (query.success && query.data.bde_id) {
    conditions.push(eq(dailyProgressTable.bde_id, query.data.bde_id));
  }
  if (query.success && query.data.date) {
    conditions.push(eq(dailyProgressTable.date, query.data.date));
  }

  const rows = await db
    .select()
    .from(dailyProgressTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(dailyProgressTable.date);

  res.json(ListProgressResponse.parse(rows));
});

router.get("/progress/today", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const today = todayStr();
  let [row] = await db
    .select()
    .from(dailyProgressTable)
    .where(and(eq(dailyProgressTable.bde_id, emp.id), eq(dailyProgressTable.date, today)));

  if (!row) {
    [row] = await db
      .insert(dailyProgressTable)
      .values({
        bde_id: emp.id,
        date: today,
        messages_sent: 0,
        leads_added: 0,
        interested_leads: 0,
        follow_ups_done: 0,
        sales_closed: 0,
      })
      .returning();
  }

  res.json(GetTodayProgressResponse.parse(row));
});

router.patch("/progress/today", requireAuth, async (req, res): Promise<void> => {
  const emp = await getSessionEmployee(req);
  if (!emp) { res.status(401).json({ error: "Not authenticated" }); return; }

  const parsed = UpdateTodayProgressBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const today = todayStr();

  let [existing] = await db
    .select()
    .from(dailyProgressTable)
    .where(and(eq(dailyProgressTable.bde_id, emp.id), eq(dailyProgressTable.date, today)));

  let row;
  if (existing) {
    [row] = await db
      .update(dailyProgressTable)
      .set(parsed.data)
      .where(eq(dailyProgressTable.id, existing.id))
      .returning();
  } else {
    [row] = await db
      .insert(dailyProgressTable)
      .values({
        bde_id: emp.id,
        date: today,
        messages_sent: parsed.data.messages_sent ?? 0,
        leads_added: parsed.data.leads_added ?? 0,
        interested_leads: parsed.data.interested_leads ?? 0,
        follow_ups_done: parsed.data.follow_ups_done ?? 0,
        sales_closed: parsed.data.sales_closed ?? 0,
      })
      .returning();
  }

  if (parsed.data.messages_sent !== undefined) {
    await db.insert(activitiesTable).values({
      bde_id: emp.id,
      action: "Progress Updated",
      description: `Daily progress updated: ${parsed.data.messages_sent} messages sent`,
    });
  }

  res.json(UpdateTodayProgressResponse.parse(row));
});

export default router;
