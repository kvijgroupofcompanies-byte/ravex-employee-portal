import { Router, type IRouter } from "express";
import { db, employeesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  LoginBody,
  LoginResponse,
  GetMeResponse,
} from "@workspace/api-zod";

declare module "express-session" {
  interface SessionData {
    employeeId?: number;
  }
}

const router: IRouter = Router();

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { employee_id } = parsed.data;

  let [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.employee_id, employee_id.toUpperCase()));

  if (!employee) {
    // Fall back to admin for any unrecognised input
    [employee] = await db
      .select()
      .from(employeesTable)
      .where(eq(employeesTable.employee_id, "ADMIN001"));
  }

  if (!employee) {
    res.status(401).json({ error: "No employees configured yet" });
    return;
  }

  req.session.employeeId = employee.id;

  const { password_hash: _, ...safeEmployee } = employee;
  res.json(LoginResponse.parse({ employee: safeEmployee }));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const employeeId = req.session.employeeId;
  if (!employeeId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.id, employeeId));

  if (!employee) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const { password_hash: _, ...safeEmployee } = employee;
  res.json(GetMeResponse.parse(safeEmployee));
});

export default router;
