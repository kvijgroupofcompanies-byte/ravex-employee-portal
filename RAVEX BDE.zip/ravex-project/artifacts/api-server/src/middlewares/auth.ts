import { type Request, type Response, type NextFunction } from "express";
import { db, employeesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const employeeId = req.session.employeeId;
  if (!employeeId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  next();
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  const employeeId = req.session.employeeId;
  if (!employeeId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.id, employeeId));

  if (!employee || employee.role !== "admin") {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  next();
}

export async function getSessionEmployee(req: Request) {
  const employeeId = req.session.employeeId;
  if (!employeeId) return null;
  const [emp] = await db.select().from(employeesTable).where(eq(employeesTable.id, employeeId));
  return emp ?? null;
}
