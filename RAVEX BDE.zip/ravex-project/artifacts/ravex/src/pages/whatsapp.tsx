import { PageHeader } from "@/components/ui-custom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Copy, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function WhatsApp() {
  const { toast } = useToast();
  const [clientName, setClientName] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [language, setLanguage] = useState("english");
  const [msgType, setMsgType] = useState("intro");
  const [generatedMsg, setGeneratedMsg] = useState("");

  const generateMessage = () => {
    const name = clientName || "[Client Name]";
    const biz = businessType || "[Business Type]";
    let msg = "";

    if (msgType === "intro") {
      if (language === "english") {
        msg = `Hi ${name}, I'm from RAVEX — we create professional websites starting at just ₹999! Our Starter Package includes Mobile Responsive Design, Contact Form, WhatsApp Integration, and Source Files. Perfect for ${biz} businesses. Interested? Let's connect! \n\n— RAVEX Team | WhatsApp: +91 8113021829`;
      } else if (language === "malayalam") {
        msg = `നമസ്കാരം ${name}, ഞാൻ RAVEX-ൽ നിന്നാണ് — ഞങ്ങൾ വെറും ₹999 മുതൽ പ്രൊഫഷണൽ വെബ്സൈറ്റുകൾ നിർമ്മിച്ചു നൽകുന്നു! ഞങ്ങളുടെ സ്റ്റാർട്ടർ പാക്കേജിൽ മൊബൈൽ റെസ്പോൺസീവ് ഡിസൈൻ, കോൺടാക്റ്റ് ഫോം, വാട്സ്ആപ്പ് ഇന്റഗ്രേഷൻ എന്നിവ ഉൾപ്പെടുന്നു. നിങ്ങളുടെ ${biz} ബിസിനസ്സിന് ഏറ്റവും അനുയോജ്യമായത്. താല്പര്യമുണ്ടോ? കൂടുതൽ വിവരങ്ങൾക്ക് ബന്ധപ്പെടുക! \n\n— RAVEX Team | WhatsApp: +91 8113021829`;
      } else {
        msg = `नमस्ते ${name}, मैं RAVEX से हूँ — हम मात्र ₹999 में प्रोफेशनल वेबसाइट्स बनाते हैं! हमारे स्टार्टर पैकेज में मोबाइल रिस्पॉन्सिव डिज़ाइन, कॉन्टैक्ट फॉर्म, और व्हाट्सएप इंटीग्रेशन शामिल हैं। ${biz} व्यवसाय के लिए बेहतरीन। रुचि है? आइए जुड़ें! \n\n— RAVEX Team | WhatsApp: +91 8113021829`;
      }
    } else if (msgType === "offer") {
      msg = `Hi ${name}, special offer for your ${biz}! Get a complete website for just ₹999 by RAVEX. Let me know if you want to see some samples.`;
    } else {
      msg = `Hi ${name}, just following up on our conversation about your website for ${biz}... Let me know if you have any questions!`;
    }

    setGeneratedMsg(msg);
  };

  const copyToClipboard = () => {
    if (!generatedMsg) return;
    navigator.clipboard.writeText(generatedMsg);
    toast({ title: "Copied to clipboard" });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <PageHeader title="WhatsApp Generator" description="Generate professional messages instantly." />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4 p-6 bg-card border border-border rounded-xl">
          <div className="space-y-2">
            <Label>Client Name</Label>
            <Input value={clientName} onChange={e => setClientName(e.target.value)} placeholder="e.g. Rahul" />
          </div>
          <div className="space-y-2">
            <Label>Business Type</Label>
            <Input value={businessType} onChange={e => setBusinessType(e.target.value)} placeholder="e.g. Restaurant" />
          </div>
          <div className="space-y-2">
            <Label>Language</Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english">English</SelectItem>
                <SelectItem value="malayalam">Malayalam</SelectItem>
                <SelectItem value="hindi">Hindi</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Message Type</Label>
            <Select value={msgType} onValueChange={setMsgType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="intro">Introduction</SelectItem>
                <SelectItem value="offer">Website Offer</SelectItem>
                <SelectItem value="followup">Follow-Up</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={generateMessage} className="w-full">Generate Message</Button>
        </div>

        <div className="space-y-4 p-6 bg-card border border-border rounded-xl flex flex-col">
          <Label>Generated Message</Label>
          <Textarea 
            value={generatedMsg} 
            onChange={e => setGeneratedMsg(e.target.value)}
            className="flex-1 min-h-[200px] resize-none"
            placeholder="Your message will appear here..."
          />
          <div className="flex gap-2">
            <Button variant="secondary" onClick={copyToClipboard} className="flex-1">
              <Copy className="h-4 w-4 mr-2" /> Copy
            </Button>
            <Button variant="outline" onClick={generateMessage} size="icon">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
