import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useGetTodayProgress, useUpdateTodayProgress, getGetTodayProgressQueryKey } from "@workspace/api-client-react";
import { PageHeader } from "@/components/ui-custom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Minus } from "lucide-react";

export default function Targets() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { data: progress, isLoading } = useGetTodayProgress();
  const updateProgress = useUpdateTodayProgress();

  const targets = {
    messages_sent: 100,
    leads_added: 30,
    interested_leads: 5,
    follow_ups_done: 10,
    sales_closed: 1
  };

  const handleUpdate = (field: keyof typeof targets, change: number) => {
    if (!progress) return;
    
    const currentValue = progress[field as keyof typeof progress] as number || 0;
    const newValue = Math.max(0, currentValue + change);
    
    // Optimistic update
    queryClient.setQueryData(getGetTodayProgressQueryKey(), {
      ...progress,
      [field]: newValue
    });

    updateProgress.mutate({
      data: { [field]: newValue }
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Daily Targets" description="Loading your targets..." />
        <div className="space-y-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full bg-card" />)}
        </div>
      </div>
    );
  }

  const statConfig = [
    { key: "messages_sent", title: "Messages Sent", desc: "Total cold outreach messages sent today." },
    { key: "leads_added", title: "Leads Added", desc: "New prospects added to the system." },
    { key: "interested_leads", title: "Interested Leads", desc: "Leads who showed interest in our services." },
    { key: "follow_ups_done", title: "Follow-ups Done", desc: "Follow-up conversations completed today." },
    { key: "sales_closed", title: "Sales Closed", desc: "Successful conversions and sales closed." },
  ] as const;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <PageHeader title="Daily Targets" description="Update your progress for today's targets." />

      <div className="space-y-4">
        {statConfig.map(stat => {
          const value = (progress?.[stat.key as keyof typeof progress] as number) || 0;
          const target = targets[stat.key];
          const percentage = Math.min(100, Math.round((value / target) * 100));

          return (
            <Card key={stat.key} className="bg-card">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg">{stat.title}</CardTitle>
                  <CardDescription>{stat.desc}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={() => handleUpdate(stat.key, -1)} disabled={value <= 0}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <div className="w-16 text-center font-bold text-lg">{value}</div>
                  <Button variant="outline" size="icon" onClick={() => handleUpdate(stat.key, 1)}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between text-sm mb-2 font-medium">
                  <span className="text-muted-foreground">{percentage}% completed</span>
                  <span className="text-primary">Target: {target}</span>
                </div>
                <Progress value={percentage} className="h-2" />
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
