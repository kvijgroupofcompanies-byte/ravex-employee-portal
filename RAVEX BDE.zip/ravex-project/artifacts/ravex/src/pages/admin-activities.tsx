import { useListActivities } from "@workspace/api-client-react";
import { PageHeader } from "@/components/ui-custom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminActivities() {
  const { data: activities, isLoading } = useListActivities({ limit: 100 });

  return (
    <div className="space-y-6">
      <PageHeader title="Activity Log" description="System-wide action history." />

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[180px]">Time</TableHead>
              <TableHead>Employee</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Details</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[80px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[250px]" /></TableCell>
                </TableRow>
              ))
            ) : activities?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                  No activities found.
                </TableCell>
              </TableRow>
            ) : (
              activities?.map(act => (
                <TableRow key={act.id}>
                  <TableCell className="text-muted-foreground">
                    {format(new Date(act.created_at), "MMM d, yyyy HH:mm")}
                  </TableCell>
                  <TableCell className="font-medium">{act.bde_name}</TableCell>
                  <TableCell className="capitalize font-medium">{act.action.replace("_", " ")}</TableCell>
                  <TableCell className="max-w-[400px] truncate">{act.description || "-"}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
