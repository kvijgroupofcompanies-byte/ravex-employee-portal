import { PageHeader } from "@/components/ui-custom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Knowledge() {
  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader title="Knowledge Center" description="Resources and package details." />

      <div className="grid gap-6">
        <Card className="bg-card">
          <CardHeader>
            <CardTitle className="text-primary">About RAVEX</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
            <p>
              RAVEX is a fast-growing web development agency focused on providing highly affordable, professional websites for small businesses and independent professionals. 
            </p>
            <p>
              We believe that every business deserves an online presence without breaking the bank. As a KVIJ Group of Companies concern, we maintain high standards of quality and customer service.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-primary/20 shadow-[0_0_15px_rgba(0,229,204,0.1)]">
          <CardHeader>
            <CardTitle>Starter Package - ₹999</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">Our most popular package, perfect for businesses getting online for the first time.</p>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
              {[
                "Mobile Responsive Design",
                "Contact Form Integration",
                "WhatsApp Chat Button",
                "Social Media Links",
                "SEO Basic Setup",
                "Source Files Provided",
                "Fast Loading Speed",
                "1 Year Free Minor Updates"
              ].map((feature, i) => (
                <li key={i} className="flex items-center gap-2 text-sm">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  {feature}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex items-center gap-4 p-3 bg-accent/50 rounded-lg">
              <span className="font-semibold w-24">WhatsApp:</span>
              <span className="text-primary font-mono">+91 8113021829</span>
            </div>
            <div className="flex items-center gap-4 p-3 bg-accent/50 rounded-lg">
              <span className="font-semibold w-24">Email:</span>
              <span className="text-primary font-mono">enquiry.ravex@gmail.com</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
