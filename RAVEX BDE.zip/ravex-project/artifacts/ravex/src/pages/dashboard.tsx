import { useAuth } from "@/lib/auth";
import { useGetTodayProgress, useUpdateTodayProgress } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/ui-custom";
import { MessageSquare, Users, UserPlus, PhoneCall, CheckCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: progress, isLoading } = useGetTodayProgress();

  const targets = {
    messages_sent: 100,
    leads_added: 30,
    interested_leads: 5,
    follow_ups_done: 10,
    sales_closed: 1
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Dashboard" description="Loading your stats..." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-32 w-full bg-card" />)}
        </div>
      </div>
    );
  }

  const stats = [
    { title: "Messages Sent", value: progress?.messages_sent || 0, target: targets.messages_sent, icon: MessageSquare },
    { title: "Leads Added", value: progress?.leads_added || 0, target: targets.leads_added, icon: Users },
    { title: "Interested Leads", value: progress?.interested_leads || 0, target: targets.interested_leads, icon: UserPlus },
    { title: "Follow-ups Done", value: progress?.follow_ups_done || 0, target: targets.follow_ups_done, icon: PhoneCall },
    { title: "Sales Closed", value: progress?.sales_closed || 0, target: targets.sales_closed, icon: CheckCircle },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={`Welcome back, ${user?.name}`} description="Here is your progress for today." />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {stats.map((stat, i) => (
          <Card key={i} className="bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value} <span className="text-sm font-normal text-muted-foreground">/ {stat.target}</span></div>
              <Progress value={(stat.value / stat.target) * 100} className="h-2 mt-3" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
