import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
const logo = "/ravex-logo.png";

const loginSchema = z.object({
  employee_id: z.string().min(1, "Employee ID is required"),
  password: z.string().min(1, "Password is required"),
});

export default function Login() {
  const { user, login, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user) {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      employee_id: "",
      password: "",
    },
  });

  function onSubmit(values: z.infer<typeof loginSchema>) {
    login(values);
  }

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background text-foreground">Loading...</div>;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <img src={logo} alt="RAVEX" className="h-40 w-40 object-contain" style={{ mixBlendMode: "screen", filter: "drop-shadow(0 0 12px rgba(0,229,204,0.5))" }} />
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-primary">RAVEX</h1>
            <p className="text-muted-foreground mt-2">Affordable Website Creation Services</p>
            <p className="text-xs text-muted-foreground mt-1 opacity-70 uppercase tracking-widest">A KVIJ Group of Companies Concern</p>
          </div>
        </div>

        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="employee_id"
                  render={({ field }) => (
                    <FormItem>
                      <Label>Employee ID</Label>
                      <FormControl>
                        <Input placeholder="Enter your ID" {...field} className="bg-input border-border focus-visible:ring-primary" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <Label>Password</Label>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} className="bg-input border-border focus-visible:ring-primary" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full font-bold">
                  Sign In
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
