import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useListFollowUps, useCreateFollowUp, useUpdateFollowUp, useDeleteFollowUp } from "@workspace/api-client-react";
import type { FollowUp, FollowUpInput } from "@workspace/api-client-react/src/generated/api.schemas";
import { PageHeader } from "@/components/ui-custom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function FollowUps() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: followups, isLoading, refetch } = useListFollowUps({ bde_id: user?.id, pending: true });
  
  const createFollowup = useCreateFollowUp();
  const updateFollowup = useUpdateFollowUp();
  const deleteFollowup = useDeleteFollowUp();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editFu, setEditFu] = useState<FollowUp | null>(null);
  
  const [formData, setFormData] = useState<Partial<FollowUpInput>>({
    client_name: "",
    follow_up_date: new Date().toISOString().split("T")[0],
    notes: ""
  });

  const handleMarkDone = (id: number, done: boolean) => {
    updateFollowup.mutate({ id, data: { done } }, {
      onSuccess: () => refetch()
    });
  };

  const handleSave = async () => {
    try {
      if (editFu) {
        await updateFollowup.mutateAsync({ id: editFu.id, data: formData });
        toast({ title: "Follow-up updated" });
      } else {
        await createFollowup.mutateAsync({ data: formData as FollowUpInput });
        toast({ title: "Follow-up created" });
      }
      setIsAddOpen(false);
      setEditFu(null);
      refetch();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this follow-up?")) {
      try {
        await deleteFollowup.mutateAsync({ id });
        toast({ title: "Follow-up deleted" });
        refetch();
      } catch (err: any) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    }
  };

  const openAdd = () => {
    setEditFu(null);
    setFormData({
      client_name: "",
      follow_up_date: new Date().toISOString().split("T")[0],
      notes: ""
    });
    setIsAddOpen(true);
  };

  const openEdit = (fu: FollowUp) => {
    setEditFu(fu);
    setFormData({
      client_name: fu.client_name,
      follow_up_date: new Date(fu.follow_up_date).toISOString().split("T")[0],
      notes: fu.notes || ""
    });
    setIsAddOpen(true);
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Follow-Ups" description="Track your scheduled calls and messages.">
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Follow-up
        </Button>
      </PageHeader>

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">Done</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[150px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[200px]" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-[60px] ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : followups?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                  No pending follow-ups. Great job!
                </TableCell>
              </TableRow>
            ) : (
              followups?.map(fu => (
                <TableRow key={fu.id} className={fu.done ? "opacity-50" : ""}>
                  <TableCell>
                    <Checkbox 
                      checked={fu.done} 
                      onCheckedChange={(checked) => handleMarkDone(fu.id, checked as boolean)} 
                    />
                  </TableCell>
                  <TableCell className="font-medium whitespace-nowrap">
                    {format(new Date(fu.follow_up_date), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="font-medium">{fu.client_name}</TableCell>
                  <TableCell className="max-w-[400px]">{fu.notes || "-"}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(fu)}><Edit2 className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(fu.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>{editFu ? "Edit Follow-up" : "Add Follow-up"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Client Name</label>
              <Input value={formData.client_name} onChange={e => setFormData({...formData, client_name: e.target.value})} />
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Date</label>
              <Input type="date" value={formData.follow_up_date} onChange={e => setFormData({...formData, follow_up_date: e.target.value})} />
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Notes</label>
              <Input value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={!formData.client_name || !formData.follow_up_date}>{editFu ? "Update" : "Save"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
