import { useGetAdminDashboard, useGetPerformance, useListActivities } from "@workspace/api-client-react";
import { PageHeader } from "@/components/ui-custom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";

export default function AdminDashboard() {
  const { data: dashboard, isLoading: dashLoading } = useGetAdminDashboard();
  const { data: performance, isLoading: perfLoading } = useGetPerformance();
  const { data: activities, isLoading: actLoading } = useListActivities({ limit: 5 });

  const stats = [
    { title: "Total Leads", value: dashboard?.total_leads },
    { title: "Total Interested", value: dashboard?.total_interested },
    { title: "Total Sales", value: dashboard?.total_sales },
    { title: "Pending Follow-ups", value: dashboard?.pending_followups },
    { title: "Messages Sent Today", value: dashboard?.messages_today },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Admin Dashboard" description="Overview of company performance." />

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {stats.map((stat, i) => (
          <Card key={i} className="bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent>
              {dashLoading ? <Skeleton className="h-8 w-16" /> : <div className="text-2xl font-bold">{stat.value || 0}</div>}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-bold tracking-tight">BDE Performance</h2>
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead className="text-right">Total Leads</TableHead>
                  <TableHead className="text-right">Interested</TableHead>
                  <TableHead className="text-right">Closed</TableHead>
                  <TableHead className="text-right">Msgs Sent</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {perfLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4">Loading...</TableCell></TableRow>
                ) : performance?.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4">No performance data.</TableCell></TableRow>
                ) : (
                  performance?.map(p => (
                    <TableRow key={p.bde_id}>
                      <TableCell className="font-medium">{p.bde_name}</TableCell>
                      <TableCell className="text-right">{p.total_leads || 0}</TableCell>
                      <TableCell className="text-right">{p.interested_leads || 0}</TableCell>
                      <TableCell className="text-right font-bold text-primary">{p.closed_sales || 0}</TableCell>
                      <TableCell className="text-right">{p.messages_sent || 0}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold tracking-tight">Recent Activity</h2>
          <div className="space-y-3">
            {actLoading ? (
               Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full bg-card" />)
            ) : activities?.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground bg-card border border-border rounded-lg">No recent activity.</div>
            ) : (
              activities?.map(act => (
                <div key={act.id} className="p-3 border border-border rounded-lg bg-card text-sm">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">{act.bde_name}</span>
                    <span className="text-xs text-muted-foreground">{format(new Date(act.created_at), "HH:mm")}</span>
                  </div>
                  <div className="text-muted-foreground">
                    <span className="text-foreground capitalize">{act.action.replace("_", " ")}</span>
                    {act.description && ` - ${act.description}`}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
