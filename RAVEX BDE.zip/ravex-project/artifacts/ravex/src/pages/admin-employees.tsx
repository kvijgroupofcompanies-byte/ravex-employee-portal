import { useState } from "react";
import { useListEmployees, useCreateEmployee, useUpdateEmployee, useDeleteEmployee } from "@workspace/api-client-react";
import type { Employee, EmployeeInputRole, EmployeeInput } from "@workspace/api-client-react/src/generated/api.schemas";
import { PageHeader } from "@/components/ui-custom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminEmployees() {
  const { data: employees, isLoading, refetch } = useListEmployees();
  const createEmployee = useCreateEmployee();
  const updateEmployee = useUpdateEmployee();
  const deleteEmployee = useDeleteEmployee();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editEmp, setEditEmp] = useState<Employee | null>(null);
  
  const [formData, setFormData] = useState<Partial<EmployeeInput>>({
    name: "",
    employee_id: "",
    password: "",
    role: "bde"
  });

  const handleSave = async () => {
    try {
      if (editEmp) {
        await updateEmployee.mutateAsync({ id: editEmp.id, data: { name: formData.name, role: formData.role, password: formData.password || undefined } });
        toast({ title: "Employee updated" });
      } else {
        await createEmployee.mutateAsync({ data: formData as EmployeeInput });
        toast({ title: "Employee created" });
      }
      setIsAddOpen(false);
      setEditEmp(null);
      refetch();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this employee?")) {
      try {
        await deleteEmployee.mutateAsync({ id });
        toast({ title: "Employee deleted" });
        refetch();
      } catch (err: any) {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    }
  };

  const openAdd = () => {
    setEditEmp(null);
    setFormData({ name: "", employee_id: "", password: "", role: "bde" });
    setIsAddOpen(true);
  };

  const openEdit = (emp: Employee) => {
    setEditEmp(emp);
    setFormData({ name: emp.name, employee_id: emp.employee_id, password: "", role: emp.role as EmployeeInputRole });
    setIsAddOpen(true);
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Employees" description="Manage access and accounts.">
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Employee
        </Button>
      </PageHeader>

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Emp ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[60px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-[80px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-[60px] ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : employees?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                  No employees found.
                </TableCell>
              </TableRow>
            ) : (
              employees?.map(emp => (
                <TableRow key={emp.id}>
                  <TableCell className="font-mono text-muted-foreground">{emp.employee_id}</TableCell>
                  <TableCell className="font-medium">{emp.name}</TableCell>
                  <TableCell>
                    <Badge variant={emp.role === "admin" ? "default" : "secondary"} className="uppercase text-xs">
                      {emp.role}
                    </Badge>
                  </TableCell>
                  <TableCell>{emp.created_at ? format(new Date(emp.created_at), "MMM d, yyyy") : "-"}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(emp)}><Edit2 className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(emp.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>{editEmp ? "Edit Employee" : "Add Employee"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Name</label>
              <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
            </div>
            {!editEmp && (
              <div className="grid gap-2">
                <label className="text-sm font-medium">Employee ID</label>
                <Input value={formData.employee_id} onChange={e => setFormData({...formData, employee_id: e.target.value})} />
              </div>
            )}
            <div className="grid gap-2">
              <label className="text-sm font-medium">Role</label>
              <Select value={formData.role} onValueChange={(v: EmployeeInputRole) => setFormData({...formData, role: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="bde">BDE</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <label className="text-sm font-medium">Password {editEmp && "(Leave blank to keep)"}</label>
              <Input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={!formData.name || (!editEmp && !formData.password)}>{editEmp ? "Update" : "Save"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
