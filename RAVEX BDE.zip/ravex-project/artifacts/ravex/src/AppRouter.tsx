import { Switch, Route, Redirect } from "wouter";
import { AuthProvider, useAuth } from "@/lib/auth";
import { Layout } from "@/components/layout";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Leads from "@/pages/leads";
import WhatsApp from "@/pages/whatsapp";
import Knowledge from "@/pages/knowledge";
import FollowUps from "@/pages/followups";
import Targets from "@/pages/targets";
import AdminDashboard from "@/pages/admin-dashboard";
import AdminEmployees from "@/pages/admin-employees";
import AdminLeads from "@/pages/admin-leads";
import AdminActivities from "@/pages/admin-activities";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component, adminOnly = false, ...rest }: any) {
  const { user, isAdmin } = useAuth();
  
  return (
    <Route
      {...rest}
      component={() => {
        if (!user) return <Redirect to="/login" />;
        if (adminOnly && !isAdmin) return <Redirect to="/dashboard" />;
        
        return (
          <Layout>
            <Component />
          </Layout>
        );
      }}
    />
  );
}

export function AppRouter() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/dashboard" component={Dashboard} />
      <ProtectedRoute path="/leads" component={Leads} />
      <ProtectedRoute path="/whatsapp" component={WhatsApp} />
      <ProtectedRoute path="/knowledge" component={Knowledge} />
      <ProtectedRoute path="/followups" component={FollowUps} />
      <ProtectedRoute path="/targets" component={Targets} />
      
      <ProtectedRoute path="/admin" component={AdminDashboard} adminOnly={true} />
      <ProtectedRoute path="/admin/employees" component={AdminEmployees} adminOnly={true} />
      <ProtectedRoute path="/admin/leads" component={AdminLeads} adminOnly={true} />
      <ProtectedRoute path="/admin/activities" component={AdminActivities} adminOnly={true} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

