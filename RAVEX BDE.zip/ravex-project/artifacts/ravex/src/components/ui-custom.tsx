import { Badge } from "@/components/ui/badge";

export function PageHeader({ title, description, children }: { title: string; description?: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {description && <p className="text-muted-foreground mt-1">{description}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    new: "default",
    contacted: "secondary",
    interested: "default",
    follow_up: "outline",
    closed: "default"
  };

  const colors: Record<string, string> = {
    new: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    contacted: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    interested: "bg-primary/10 text-primary border-primary/20",
    follow_up: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    closed: "bg-green-500/10 text-green-500 border-green-500/20",
  };

  return (
    <Badge variant="outline" className={`capitalize font-medium ${colors[status] || ""}`}>
      {status.replace("_", " ")}
    </Badge>
  );
}
