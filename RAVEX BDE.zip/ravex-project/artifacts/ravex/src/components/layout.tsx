import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import {
  LayoutDashboard,
  Users,
  MessageSquare,
  MessageCircle,
  Target,
  BookOpen,
  LogOut,
  Activity,
  ShieldAlert,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout, isAdmin } = useAuth();
  const [location] = useLocation();

  if (!user) return <>{children}</>;

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/leads", label: "Leads", icon: Users },
    { href: "/followups", label: "Follow-Ups", icon: MessageSquare },
    { href: "/whatsapp", label: "WhatsApp Gen", icon: MessageCircle },
    { href: "/targets", label: "Targets", icon: Target },
    { href: "/knowledge", label: "Knowledge Base", icon: BookOpen },
  ];

  const adminItems = [
    { href: "/admin", label: "Admin Panel", icon: ShieldAlert },
    { href: "/admin/employees", label: "Employees", icon: Users },
    { href: "/admin/leads", label: "All Leads", icon: Users },
    { href: "/admin/activities", label: "Activity Log", icon: Activity },
  ];

  const NavLinks = () => (
    <>
      <div className="space-y-1 py-4">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={`flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                location === item.href
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              }`}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </div>
          </Link>
        ))}
      </div>

      {isAdmin && (
        <div className="space-y-1 py-4 border-t border-border">
          <div className="px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
            Admin
          </div>
          {adminItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                  location === item.href
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col border-r border-border bg-card">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <img src="/ravex-logo.png" alt="RAVEX" className="h-8 w-8 object-contain" style={{ mixBlendMode: "screen" }} />
          <div className="font-bold text-xl tracking-tight text-primary">RAVEX</div>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2">
          <NavLinks />
        </div>
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-sm font-medium">{user.name}</span>
              <span className="text-xs text-muted-foreground capitalize">{user.role}</span>
            </div>
            <Button variant="ghost" size="icon" onClick={() => logout()} title="Logout">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile Header & Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden flex items-center justify-between p-4 border-b border-border bg-card">
          <div className="flex items-center gap-3">
            <img src="/ravex-logo.png" alt="RAVEX" className="h-8 w-8 object-contain" style={{ mixBlendMode: "screen" }} />
            <div className="font-bold text-xl tracking-tight text-primary">RAVEX</div>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0 flex flex-col bg-card">
              <div className="p-6 border-b border-border flex items-center justify-between">
                <div className="font-bold text-xl tracking-tight text-primary">RAVEX</div>
              </div>
              <div className="flex-1 overflow-y-auto px-3 py-2">
                <NavLinks />
              </div>
              <div className="p-4 border-t border-border">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{user.name}</span>
                    <span className="text-xs text-muted-foreground capitalize">{user.role}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => logout()}>
                    <LogOut className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 p-6 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
