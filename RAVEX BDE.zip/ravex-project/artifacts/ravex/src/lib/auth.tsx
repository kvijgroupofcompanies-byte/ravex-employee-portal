import { createContext, useContext, ReactNode, useEffect } from "react";
import { useGetMe, useLogin, useLogout } from "@workspace/api-client-react";
import type { Employee, LoginInput } from "@workspace/api-client-react/src/generated/api.schemas";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

type AuthContextType = {
  user: Employee | null;
  isLoading: boolean;
  login: (data: LoginInput) => void;
  logout: () => void;
  isAdmin: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const { data: user, isLoading, isError, error } = useGetMe({
    query: {
      retry: false,
    }
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: () => {
        setLocation("/dashboard");
        // We'll let the user fetch automatically by invalidating, but getMe doesn't have an invalidate yet,
        // we can just reload the window or let the redirect happen
        window.location.href = "/dashboard";
      },
      onError: (err: any) => {
        toast({
          title: "Login failed",
          description: err?.message || "Invalid credentials",
          variant: "destructive"
        });
      }
    }
  });

  const logoutMutation = useLogout({
    mutation: {
      onSuccess: () => {
        window.location.href = "/login";
      }
    }
  });

  const handleLogin = (data: LoginInput) => {
    loginMutation.mutate({ data });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <AuthContext.Provider
      value={{
        user: user || null,
        isLoading,
        login: handleLogin,
        logout: handleLogout,
        isAdmin: user?.role === "admin"
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
